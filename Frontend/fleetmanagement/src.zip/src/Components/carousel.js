
import React, { useState } from 'react';
import { Carousel, Form, Button, Container, Row, Col } from 'react-bootstrap';
import './carousel.css';
import { useNavigate } from 'react-router-dom';

const BookingForm = () => {
    const [formData, setFormData] = useState({
        rentalDate: '',
        rentalTime: '',
        returnDate: '',
        returnTime: '',
        pickupLocation: '',
        pickupState: '', 
        pickupCity: '',  
        returnLocation: '',
        returnState: '',
        returnCity: '',  
        returnToDifferentLocation: false,
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const navigate=useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('./LoginForm');
    };

    return (
        <Container fluid>
            <Carousel>
                <Carousel.Item>
                    <div className="carousel-item" style={{ backgroundImage: `url("https://images.pexels.com/photos/29648178/pexels-photo-29648178/free-photo-of-vintage-mercedes-300sl-car-on-rocky-terrain.jpeg")` }}>
                        <Row className="booking-container">
                            <Col md={8}>
                                <div className="overlay">
                                    <h2 className="mb-4">Make Booking</h2>
                                    <Form onSubmit={handleSubmit} className="booking-form">
                                        <Row>
                                            <Col md={6}>
                                                <Form.Group controlId="rentalDate">
                                                    <Form.Label>Rental Date:</Form.Label>
                                                    <Form.Control type="date" name="rentalDate" value={formData.rentalDate} onChange={handleChange} required />
                                                </Form.Group>
                                            </Col>
                                            <Col md={6}>
                                                <Form.Group controlId="rentalTime">
                                                    <Form.Label>Rental Time:</Form.Label>
                                                    <Form.Control type="time" name="rentalTime" value={formData.rentalTime} onChange={handleChange} required />
                                                </Form.Group>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col md={6}>
                                                <Form.Group controlId="returnDate">
                                                    <Form.Label>Return Date:</Form.Label>
                                                    <Form.Control type="date" name="returnDate" value={formData.returnDate} onChange={handleChange} required />
                                                </Form.Group>
                                            </Col>
                                            <Col md={6}>
                                                <Form.Group controlId="returnTime">
                                                    <Form.Label>Return Time:</Form.Label>
                                                    <Form.Control type="time" name="returnTime" value={formData.returnTime} onChange={handleChange} required />
                                                </Form.Group>
                                            </Col>
                                        </Row>

                                        <Form.Group controlId="pickupLocation">
                                            <Form.Label>Pickup Location:</Form.Label>
                                            <Form.Control as="select" name="pickupLocation" value={formData.pickupLocation} onChange={handleChange}>
                                                <option>Select Pickup Location</option>

                                            </Form.Control>
                                        </Form.Group>
                                        <Form.Group className='chk-1' controlId="returnToDifferentLocation">
                                            <Form.Check type="checkbox" name="returnToDifferentLocation" checked={formData.returnToDifferentLocation} onChange={handleChange} label="I may return the car to a different location" />
                                        </Form.Group>
                                        <Row>
                                            <Col md={6}>
                                                <Form.Group controlId="pickupState">
                                                    <Form.Label>Pickup State:</Form.Label>
                                                    <Form.Control type="text" name="pickupState" value={formData.pickupState} onChange={handleChange} placeholder="Enter pickup state" required />
                                                </Form.Group>
                                            </Col>
                                            <Col md={6}>
                                                <Form.Group controlId="pickupCity">
                                                    <Form.Label>Pickup City:</Form.Label>
                                                    <Form.Control type="text" name="pickupCity" value={formData.pickupCity} onChange={handleChange} placeholder="Enter pickup city" required />
                                                </Form.Group>
                                            </Col>
                                        </Row>

                                        <Form.Group controlId="returnLocation">
                                            <Form.Label>Return Location:</Form.Label>
                                            <Form.Control as="select" name="returnLocation" value={formData.returnLocation} onChange={handleChange}>
                                                <option>Select Return Location</option>
                                            </Form.Control>
                                        </Form.Group>
                                        <Row>
                                            <Col md={6}>
                                                <Form.Group controlId="returnState">
                                                    <Form.Label>Return State:</Form.Label>
                                                    <Form.Control type="text" name="returnState" value={formData.returnState} onChange={handleChange} placeholder="Enter return state" required />
                                                </Form.Group>
                                            </Col>
                                            <Col md={6}>
                                                <Form.Group controlId="returnCity">
                                                    <Form.Label>Return City:</Form.Label>
                                                    <Form.Control type="text" name="returnCity" value={formData.returnCity} onChange={handleChange} placeholder="Enter return city" required />
                                                </Form.Group>
                                            </Col>
                                        </Row>
                                        <Button variant="primary" type="submit">Continue Booking</Button>
                                    </Form>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </Carousel.Item>
            </Carousel>
        </Container>
    );
};

export default BookingForm;


