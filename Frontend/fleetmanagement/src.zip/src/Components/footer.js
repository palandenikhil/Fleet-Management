import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import '@fortawesome/fontawesome-free/css/all.css';

function Footer() {
  return (
    <footer className="bg-dark text-light py-4">
      <Container>
        <Row>
          <Col md={6}>
            <p>&copy; {new Date().getFullYear()} Hire&GO.</p>
            <p>All rights reserved.</p>
            <p>Contact us at: <a href="mailto:hireandgo@gmail.com" className="text-light">contact@hire&go.com</a></p>
          </Col>
          <Col md={6}>
            <h5>Quick Links</h5>
            <ul className="list-unstyled">
              <li><Link to="/aboutus" className="text-light" style={{ textDecoration: 'none' }}>About Us</Link></li>
              <li><Link to="/services" className="text-light" style={{ textDecoration: 'none' }}>Services</Link></li>
              <li><Link to="/contact" className="text-light" style={{ textDecoration: 'none' }}>Contact Us</Link></li>
            </ul>
          </Col>
        </Row>
        <Row>
          <Col>
            <div className="social-icons">
              <a href="https://facebook.com" className="text-light me-3" target="_blank" rel="noopener noreferrer">
                <i className="fa-brands fa-facebook"></i>
              </a>
              <a href="https://twitter.com" className="text-light me-3" target="_blank" rel="noopener noreferrer">
                <i className="fa-brands fa-twitter"></i>
              </a>
              <a href="https://instagram.com" className="text-light" target="_blank" rel="noopener noreferrer">
                <i className="fa-brands fa-instagram"></i>
              </a>
            </div>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

export default Footer;
