import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import LoginForm from "./Component/LoginForm";
import Signup from "./Component/Signup";
import Home from "./Component/home";
import VehicleSelection from "./Component/VehicleSelection";
import HubSelection from "./Component/HubSelection";
import SelectLocation from "./Component/SelectLocation";
import Landing from "./Component/Landing";

const App = () => {
  return (
    <Router future={{ v7_relativeSplatPath: true }}>  {/* Enable the future flag */}
      <Routes>
        {/* Define your routes here */}
        <Route path="/" element={<Landing/>} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/LoginForm" element={<LoginForm />} />
        {/* <Route path="/h" element={<VehicleSelection />} /> */}
        <Route path="/VehicleSelection" element={<VehicleSelection />} />
        <Route path="/SelectLocation" element={<SelectLocation />} />
        <Route path="/HubSelection" element={<HubSelection />} />
        {/* Other routes */}
      </Routes>
    </Router>
  );
};

export default App;










