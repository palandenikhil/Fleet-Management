import './App.css';
import Home from './Components/home';
import Navbar from './Components/navbar';
import Footer from './Components/footer';
import { BrowserRouter as Router} from 'react-router-dom';
import LocationSelection from './hub-selection';
import VehicleSelection from './VehicleSelection';
import LoginForm from './Components/LoginForm';
import { Carousel } from 'react-bootstrap';
// import  from './Registration';

function App() {
  return (
    <Router>
      <div className="App">
        <Home/>
        <Navbar/>
        <Footer/>
        {/* <LocationSelection/> */}
        {/* <VehicleSelection/> */}
        {/* <LoginForm/> */}
      </div>
    </Router>    
  );
}

export default App;
