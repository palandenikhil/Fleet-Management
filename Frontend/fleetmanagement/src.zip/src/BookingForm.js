import React, { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';

const BookingForm = () => {
    const [formData, setFormData] = useState({
        rentalDate: '',
        rentalTime: '',
        returnDate: '',
        returnTime: '',
        pickupLocation: '',
        returnLocation: '',
        returnToDifferentLocation: false,
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert("Booking Submitted!");
    };

    return (
        <Container fluid style={{ backgroundImage: `url("https://via.placeholder.com/1500x1000")`, backgroundSize: 'cover', minHeight: '100vh', padding: 0 }}>
            <Row className="justify-content-center" style={{ marginTop: '50px' }}>
                <Col md={8}>
                    <div style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)', borderRadius: '10px', padding: '30px', color: 'white' }}>
                        <h2 className="mb-4" style={{ textAlign: 'center' }}>Car Rental Booking</h2>
                        <Form onSubmit={handleSubmit}>
                            <Form.Group controlId="rentalDate">
                                <Form.Label>Rental Date:</Form.Label>
                                <Form.Control type="date" name="rentalDate" value={formData.rentalDate} onChange={handleChange} required />
                            </Form.Group>
                            <Form.Group controlId="rentalTime">
                                <Form.Label>Rental Time:</Form.Label>
                                <Form.Control type="time" name="rentalTime" value={formData.rentalTime} onChange={handleChange} required />
                            </Form.Group>
                            <Form.Group controlId="returnDate">
                                <Form.Label>Return Date:</Form.Label>
                                <Form.Control type="date" name="returnDate" value={formData.returnDate} onChange={handleChange} required />
                            </Form.Group>
                            <Form.Group controlId="returnTime">
                                <Form.Label>Return Time:</Form.Label>
                                <Form.Control type="time" name="returnTime" value={formData.returnTime} onChange={handleChange} required />
                            </Form.Group>
                            <Form.Group controlId="pickupLocation">
                                <Form.Label>Pickup Location:</Form.Label>
                                <Form.Control type="text" name="pickupLocation" value={formData.pickupLocation} onChange={handleChange} placeholder="Enter Pickup Location" required />
                            </Form.Group>
                            <Form.Group controlId="returnLocation">
                                <Form.Label>Return Location:</Form.Label>
                                <Form.Control type="text" name="returnLocation" value={formData.returnLocation} onChange={handleChange} placeholder="Enter Return Location" required />
                            </Form.Group>
                            <Form.Group controlId="returnToDifferentLocation">
                                <Form.Check type="checkbox" name="returnToDifferentLocation" checked={formData.returnToDifferentLocation} onChange={handleChange} label="Return car to a different location" />
                            </Form.Group>
                            <Button variant="primary" type="submit" style={{ backgroundColor: 'green', borderColor: 'green' }}>Submit Booking</Button>
                        </Form>
                    </div>
                </Col>
            </Row>
        </Container>
    );
};

export default BookingForm;
